# Skip and Force Policy

## Normal Rule

Follow stages in order unless user explicitly requests skip/bypass.

## Force and Bypass Semantics

`--force` means explicit override of normal prerequisite/progression behavior.

When force/bypass is applied:

- document bypass in stage file and status note
- move unfinished skipped stage(s) to `Incompleted stages`
- set new `Current stage` explicitly
- update `Next recommended step` accordingly

## Mandatory Stage Warning

If user bypasses a mandatory stage (`1-initializer` or `4-implementer`):

- warn clearly about risk and missing guarantees
- proceed only if user confirms bypass intent

## Traceability Requirement

Bypass never erases history. Bypassed state must remain visible in:

- `00-current-status.md`
- relevant stage file notes
- traceability/risk appendices when impacted